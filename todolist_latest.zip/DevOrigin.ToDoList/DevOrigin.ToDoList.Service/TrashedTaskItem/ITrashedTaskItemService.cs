﻿using System;
using System.Collections.Generic;
using DevOrigin.ToDoList.Data;

namespace DevOrigin.ToDoList.Service
{
  public interface ITrashedTaskItemService
  {
    IList<TrashedTaskItem> GetItems();
    TrashedTaskItem GetItem(int itemId);
  }
}
