﻿using System;
using System.Collections.Generic;
using DevOrigin.ToDoList.Data;

namespace DevOrigin.ToDoList.Service
{
  public interface ITaskItemService
  {
    IList<TaskItem> GetItems();
    TaskItem GetItem(int itemId);
    TaskItem GetDefaultItem();
    void InsertTaskItem(TaskItem item);
    void UpdateTaskItem(TaskItem item);
    void DeleteTaskItem(int itemId);
    void AccomplishTaskItem(int itemId);
  }
}
