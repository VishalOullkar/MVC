﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DevOrigin.ToDoList.Data;

namespace DevOrigin.ToDoList.Web.Views
{
  public partial class Index : ViewPage<IList<TaskItemViewModel>>
  {
  }
}
