﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using StructureMap.Configuration.DSL;
using StructureMap;
using StructureMap.Attributes;
using DevOrigin.ToDoList.Data.SqlRepository;

namespace DevOrigin.ToDoList.Data
{
  public class DBServiceRegistry : Registry
  {
    protected override void configure()
    {
      ForRequestedType<LinqTaskItemDataContext>()
        .TheDefaultIs(() => new LinqTaskItemDataContext())
        .CacheBy(InstanceScope.Hybrid);
    }
  }
}
