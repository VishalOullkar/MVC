﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DevOrigin.ToDoList.Data
{
  public interface ITaskItemRepository
  {
    IQueryable<TaskItem> GetItems();
    void InsertTaskItem(TaskItem item);
    void UpdateTaskItem(TaskItem item);
    void Delete(int itemId);
    void AccomplishTaskItem(int itemId);
  }
}
