﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DevOrigin.ToDoList.Data
{
  public interface ITrashedTaskItemRepository
  {
    IQueryable<TrashedTaskItem> GetItems();
    void InsertTaskItem(TrashedTaskItem item);
    void UpdateTaskItem(TrashedTaskItem item);
    void Delete(int itemId);
  }
}
